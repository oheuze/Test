 	if maxtime == 0
		global maxtime = 0.038
	end

 	if cfl == 0
		global cfl = 0.25
	end

	for i in ideb:ifin+1
		x[i]= 0. + (i-1-nghost)*(1.)/nbcell
		gamma = 1.4
		if x[i] <= 0.1
			rho[i]  = 1
			pmat[i] = 1000 
			umat[i] = 0 
			emat[i]=Emat[i]=pmat[i]/((gamma-1.)*rho[i])
		elseif x[i] >= 0.9
			rho[i]  = 1 
			pmat[i] = 100
			umat[i] = 0
			emat[i]=Emat[i]=pmat[i]/((gamma-1.)*rho[i])
		else
			rho[i]  = 1 
			pmat[i] = 0.01
			umat[i] = 0
			emat[i]=Emat[i]=pmat[i]/((gamma-1.)*rho[i])
		end
	end
