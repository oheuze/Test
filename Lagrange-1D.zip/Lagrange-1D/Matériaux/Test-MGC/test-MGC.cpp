﻿#include <iostream>
#include "Mat.h"  
#include "LecteurXY.hpp" 
using namespace std; 

LecteurXY donneesVE;	

int main (int argc, char* args[]) { 
	if (argc<3) 	{cout <<" Syntaxe :  test-MGC <Sn-xxx.xml> <pts.xml>" <<endl;} 
	if (argc<3) 	{cout << " Argument manquant"<<endl; } 
		else 	{ cout << " Argument " << (char*)args[1] << " " << (char*)args[2] << endl; }; 
	string xmlFile    = (string) args[1]; 
	char* xmlPtsFile = (char*) args[2]; 

	MatMGC materiau=MatMGC(xmlFile);
	materiau.LireDonnees(xmlFile);
//	materiau.ecrire();

	//	CHARGEMENT DES POINTS TESTS
	donneesVE.LireDonnees(xmlPtsFile);
	cout << "Matériau : " << donneesVE.nom << endl;
	vector <PointXY> pointsVE = donneesVE.pointsXY;
	cout << xmlPtsFile << endl; 
	cout << pointsVE.size() << " points." << endl; 
	cout << "Etats complets :"<< endl; 
	int nbPts=(int) pointsVE.size();
	double ρ[nbPts],E[nbPts];
	double p[nbPts], c[nbPts], T[nbPts], g[nbPts], S[nbPts];
	for (int i=0; i< nbPts; i++){
		materiau.calculEtatVE( pointsVE[i].x , pointsVE[i].y );
		ρ[i] = 1/pointsVE[i].x;
		E[i] = pointsVE[i].y;
	}	 
	materiau.calculEtats(0,nbPts-1,p,c,T,g,S,ρ,E);
	for (int i=0; i < nbPts; i++){
		cout << i+1 << "	ρ = " << ρ[i]<< "	V = " << 1/ρ[i] << "	E = " << E[i] 
			<< "	P = " << p[i] << "	T = " << T[i] << "	S = " << S[i] 
			<< "	c = " << c[i] << "	g = " << g[i] << endl;
	}	 
	cout << "Fin"<< endl; 

	return 0; 
} 

