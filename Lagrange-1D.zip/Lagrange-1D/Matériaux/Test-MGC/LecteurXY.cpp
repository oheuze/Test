#include "LecteurXY.hpp" 
#include "PointXY.h" 
	
LecteurXY::LecteurXY(){ 
	//cout <<" Appel de LecteurXY "<< endl;
} 

LecteurXY::~LecteurXY(){} 

void LecteurXY::ecrire(){ 
	//	cout <<" { ( "<< pt1.x <<" , "<< pt1.y <<" ) , ( "<< pt2.x <<" , " << pt2.y <<" ) } "; 
} 

int LecteurXY::LireDonnees(string ficXML) { 
	cout << "Fichier XY : " << ficXML << endl; 

	ParserSAX* parser =new ParserSAX();
	parser->detailed=false;
	XYHandler* handler = new XYHandler();
	parser->InitHandler(handler);
	parser->parse(ficXML);
	nom	= handler->nom;
	pointsXY= handler->pointsXY;

	return 0; 
} 
