#include "Mat.h"
//
// Mat
//

Mat::Mat(const std::string material)
{
	cout << material << endl;
}

void Mat::LireDonnees(std::string nomfic){
	cout << "Fichier de Données : "  << nomfic ;
	int posPt = nomfic.find(".");
	int len = nomfic.size();
	string suffixe = nomfic.substr(posPt+1,len) ;
	cout << "Suffixe détecté : " <<  suffixe  << endl ;
	cout << "Aucune lecture"<< endl; 
	cout << "Fin"<< endl; 
};

void Mat::InitParam(){
	cout << "InitParam "  << endl ;
}
	
void Mat::ecrire(){
	cout << "ecrire "  << endl ;
}

void Mat::calculPc(int ideb, int ifin, double* p,double* c, 
		const double* rho, const double* epsilon)
{
	for (int i = ideb-1; i <ifin; i++) {
	        p[i] = (γ - 1.) * rho[i] * epsilon[i];
        	c[i] = std::sqrt(γ * p[i] / rho[i]);
        }	
}

void Mat::calculEtats(int ideb, int ifin, double* p,double* c,double* T, double* g, double* S, 
		const double* rho, const double* epsilon)
{
	for (int i = ideb-1; i <ifin; i++) {
	        p[i] = (γ - 1.) * rho[i] * epsilon[i];
        	c[i] = std::sqrt(γ * p[i] / rho[i]);
        	T[i] = (γ - 1.) * epsilon[i] / R;
        }	
}
	
void Mat::calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
		const double* rho, const double* T)
{
	for (int i = 0; i < N; i++) {
	        p[i] = rho[i] * R * T[i];
        	c[i] = std::sqrt(γ * p[i] / rho[i]);
        	epsilon[i] = R * T[i] /  (γ - 1.);
        }	
}
	
void Mat::calculEtatVE(double v,double e){
	cout << "Mat.cpp 	V= " << V << "	,	" << E << endl;
	V = v;
	E = e;
	P = (γ-1)* E/V;
        c = sqrt(γ * P * V);
       	T= 300.0;
       	// à compléter
       	S=0;
       	g=0;
       	H=E+P*V;
       	F=E-T*S;
       	G=F+P*V;        
}	

