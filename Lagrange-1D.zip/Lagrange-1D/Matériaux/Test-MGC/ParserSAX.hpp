#ifndef _ParserSAX_H 
#define _ParserSAX_H 

#include <string> 
#include <iostream> 
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include "SAXHandler.hpp" 

using namespace std; 

class ParserSAX 
{ 
	public: 
	SAXHandler* handler;
	map <string,string> attributs;
	string caracteres;
	int niveau =0;
	bool detailed = false;

	ParserSAX();
	~ParserSAX();
	void InitHandler(SAXHandler* saxHandler);
	void parse(std::string nomfic);
	void gererTag(std::string TagStr);
	string trim(string str);
};

#endif 

