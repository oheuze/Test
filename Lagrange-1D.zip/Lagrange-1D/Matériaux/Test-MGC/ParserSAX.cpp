//	OH-22-04-2023
#include "ParserSAX.hpp" 

ParserSAX::ParserSAX(){  }

ParserSAX::~ParserSAX(){  cout << "ParserSAX destructeur " << endl; }

void ParserSAX::InitHandler(SAXHandler* saxHandler){	handler=saxHandler;}

string ParserSAX:: trim(string str){
	while( str.find(" ")==0 || str.find("\n")==0  || str.find("\t")==0  ) str=str.substr(1,str.size());
	string last=str.substr(str.size(),str.size());
	while( last.compare(" ")==0 || last.compare("\n")==0  || last.compare("\t")==0  ) 		
			str=str.substr(0,str.size()-1);
	return str;
}

void ParserSAX::gererTag(std::string TagStr){
	niveau++;
	char c = '"';std::string dq;dq += c;
	string nomTag = TagStr.substr(0,min(TagStr.find(" "),TagStr.find(">")));
       	//  récupération des attributs
       	std::size_t finAttr = TagStr.find(">");
       	string attr = trim(TagStr.substr(nomTag.size()+1,finAttr-nomTag.size()));
       	attributs.clear();
       	while( attr.find("=") < attr.size() ){
	       	string apres_egal= attr.substr(attr.find("=")+2,attr.size());
       		string bloc = attr.substr(0,attr.find("=")+3+apres_egal.find(dq));
	       	string motclef=trim(bloc.substr(0,bloc.find("=")));
	       	string valeur=bloc.substr(bloc.find(dq)+1,bloc.size()-bloc.find(dq)-2);
	       	attributs[motclef]=valeur;	
       		attr=trim(attr.substr(bloc.size(),attr.size()-bloc.size()));
       	}
	handler->StartElement(nomTag,attributs);	
	map <string,string>::iterator it;
	for(it=attributs.begin(); it!=attributs.end(); ++it){	
		if (detailed)	cout << "		" << it->first << "	:	"  << it->second<< endl;
	}
	bool tagLong = (TagStr.find("/>") > finAttr )  ||  (TagStr.find("</"+nomTag) > finAttr ) ;
	if (tagLong){
		//  suiteStr après les attributs , recherche des caracteres et sous-tags
		string suiteStr= TagStr.substr(	TagStr.find(">")+1,
				 TagStr.find("</"+nomTag)+nomTag.size()-TagStr.find(">")-1);
		caracteres = suiteStr.substr(0,min(suiteStr.size(), suiteStr.find("<")));
		handler->Characters(caracteres);
		suiteStr= suiteStr.substr(suiteStr.find("<")+1,suiteStr.size());
		while (( suiteStr.find(">") < suiteStr.size() ) )
       		{
	       		std::size_t nextTag = suiteStr.find("<"+1);
	       		if (nextTag < suiteStr.size() )
	       		{
       				suiteStr = suiteStr.substr(nextTag,suiteStr.size());
	       			string newTag= suiteStr.substr(0,
	       				min(suiteStr.find(" "),suiteStr.find(">")));
	       			bool tagLong = suiteStr.find("/"+newTag) < suiteStr.size();
	       			std::size_t finTag = 0;
       				if (tagLong)  {	finTag = suiteStr.find("/"+newTag)-1;}
	       				else  { finTag = suiteStr.find("/>")-1;};
				if ( newTag.find("!-")<2 ) {cout << "Commentaire " << 	suiteStr.substr(0,suiteStr.find(">")) << endl;suiteStr="                       ";}
				else
				{
					gererTag(suiteStr.substr(0,finTag));
					if (tagLong)  {	
						suiteStr=suiteStr.substr(finTag+newTag.size() ,
						 	suiteStr.size());
						}
		       				else  { suiteStr=suiteStr.substr(finTag+1 , 
		       					suiteStr.size());}
	       				suiteStr=suiteStr.substr(suiteStr.find(">")+1, 	suiteStr.size());
					//caracteres = suiteStr.substr(0,min(suiteStr.size(), 
					//	suiteStr.find("<")));
					//cout << "2 " ;
					//handler->Characters(caracteres);
					suiteStr= suiteStr.substr(suiteStr.find("<")	+1,suiteStr.size());
					nextTag = suiteStr.find("<"+1);
				}	
			}
		}
	}	
	// fin du tag
	handler->EndElement(nomTag);
	attributs.clear();
	caracteres="";
	niveau--;
}	

void ParserSAX::parse(std::string nomfic){
	cout << "Nom du fichier XML : " << nomfic << endl;
	handler->StartDocument();
	// Chargement du fichier
	std::ifstream fic(nomfic);
	std::stringstream buffer;
	buffer << fic.rdbuf();
	string chaine =buffer.str();
	//cout << "===========================================================================" << endl;
	//cout << chaine << endl;
	//cout << "===========================================================================" << endl;
	//cout << "Fin du fichier" << endl;
	string reste=chaine.substr(chaine.find("?>")+2,chaine.size());
        
       	//	Elimination des commentaires
       	while ( reste.find("<!--")<reste.size() ){
		std::size_t debut=reste.find("<!--");
       		string suite = reste.substr(debut,reste.size());
       		std::size_t fin=suite.find("-->")+3;
       		string comment= suite.substr(0,fin);
       		//cout << "Commentaire : " << comment << endl;
       		reste=reste.erase(debut,fin);
       	}
	//cout << "======================" << endl;
	//cout << reste << endl;	
	//cout << "======================" << endl;
        
        std::size_t found = reste.find("<");
	while( found < reste.size() ){
	       	reste = reste.substr(found+1,reste.size());
	       	string nomTag = reste.substr(0,min(reste.find(" "),reste.find(">")));
       		size_t finTag ;
	       	bool tagCourt (	reste.find("/>") < reste.find(">") ||
	       			reste.find("->") < reste.find(">"));
	       	if (tagCourt) {
	       		finTag = reste.find(">");
	       	} else
	       	{
	       		finTag = reste.find("</"+nomTag);
	       	}
	       	string strTag = reste.substr(0,finTag) ;
	       	
		//cout << "###"  << strTag << "###" <<endl;
	       	if ( (reste.substr(0,1).compare("!")!=0) && (reste.substr(0,1).compare("/")!=0) ){
	       		if ( nomTag.find("!-")<2 ) {
       				cout << "Commentaire " << reste.substr(0,reste.find(">")) 
       					<< endl;reste="                       ";
       			}
				else
			{	
			       	gererTag(strTag);
				if (tagCourt)  { reste = reste.substr(finTag , reste.size());}
				else
				{	
					reste = reste.substr(finTag+nomTag.size(), reste.size());
				}
			}
		}	
		reste = trim(reste.substr(reste.find(">")+1,reste.size()));
		found = reste.find("<");
	};  	
	handler->EndDocument();
	//cout << "Fin du parser" << endl;
}
