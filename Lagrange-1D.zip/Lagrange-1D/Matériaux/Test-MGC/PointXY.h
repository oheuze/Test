#ifndef _POINT_   
#define _POINT_

#include <string> 
#include <iostream> 
#include <sstream> 

using namespace std; 

class PointXY 

{ 

protected: 

public: 

	PointXY(); 

	PointXY(double X,double Y); 
	PointXY(std::string chaine); 
	virtual ~PointXY(); 

	double x,y; 

	void ecrire(); 
}; 

#endif
