#ifndef _LecteurMAT_H 
#define _LecteurMAT_H 

#include "LecteurDonnees.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <dlfcn.h>

using namespace std; 

class LecteurMAT  : public LecteurDonnees
{ 
	public: 
	string nom;
	
	LecteurMAT(); 	
	~LecteurMAT(); 

	int LireDonnees(std::string MATfile); 
	void ecrire(); 
	
	string trim(string str){
		// élimination des blancs du début
		while( str.find(" ")==0 || str.find("\n")==0  || str.find("\t")==0  ) str=str.substr(1,str.size());
		// éliminations des blancs de la fin
		string last=str.substr(str.size()-1,1);
		while( last.compare(" ")==0 || last.compare("\n")==0  || last.compare("\t")==0 ) {
			str=str.substr(0,str.size()-1);
			last = str.substr(str.size()-1,1);
		}	
		return str;
	}
} ; 

#endif 

