﻿#include "BiPoint.h"

BiPoint::BiPoint(){ } 

BiPoint::BiPoint(PointXY Pt1,PointXY Pt2){ pt1=Pt1;pt2=Pt2; } 
BiPoint::BiPoint(std::string chaine){ 
	std::string bbeg="["; std::string bmid =";"; std:: string bend="]"; 
	std::string strPt1=chaine.substr(chaine.find(bbeg)+1,chaine.find(bmid)-chaine.find(bbeg)-1); 
	std::string strPt2=chaine.substr(chaine.find(bmid)+1,chaine.find(bend)-chaine.find(bmid)-1); 
	pt1=PointXY(strPt1); 
	pt2=PointXY(strPt2); 
} 

BiPoint::~BiPoint(){} 

void BiPoint::ecrire(){ 
	cout <<" { ( "<< pt1.x <<" , "<< pt1.y <<" ) , ( "<< pt2.x <<" , " << pt2.y <<" ) } "; 
} 

