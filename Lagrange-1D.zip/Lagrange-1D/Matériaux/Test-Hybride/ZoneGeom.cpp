#include "ZoneGeom.h" 
#include <string> 
#include <iostream>

ZoneGeom:: ZoneGeom() { 	} 

ZoneGeom::ZoneGeom(int Nz,std::string strBips) {
	nz=Nz;
	bips=strToBips(strBips);
}

ZoneGeom::~ZoneGeom(){} 

vector<BiPoint> ZoneGeom::strToBips(std::string strBips){ 
	std:: string bend="]"; 
	std::string strList=strBips; 
	vector<BiPoint> bipList; 
	do { 
		std::string strBip= strList.substr(1,strList.find(bend)); 
		BiPoint bip=BiPoint(strBip); 
		bipList.push_back(bip); 
		strList=strList.substr(strList.find(bend)+1); 
	} while (strList.find(bend)<strList.length()) ;
	
	return bipList; 
}

void ZoneGeom::ecrire() { 
	cout <<"		ZoneGeom :  zone " << nz << "  segments = "  ; 
	for(std::size_t i=0; i<  bips.size();i++){ bips[i].ecrire(); if ((i%3)==2) cout << endl << "			";} ; 
	cout << endl; 
} 
