﻿#include <cmath>
#include <iostream>
#include "EoS.hpp"

//  OH-30-05-2023 

class EoS_MGC : public EoS {	

protected :
	
public:	
	// paramètres EoS_MGC	
	double Ko,No,Γo,Cvr,θo,Po,ΔV,dPdT,Tmin,Tmax,Pmin,Pmax,ρ0,Sr,ur;
		
	// grandeurs EoS_MGC	
	double Es,Ps,PsP,PsS,ε,εp,εs,εt,psi,psiP,θ,Γ,Γρ,ΓρP;
	
	EoS_MGC(map <string,string> Parametres){		
		parametres= Parametres;  
		cout << "	Initialisation EoS_MGC  ("<< parametres.size() 
				<< " paramètres ) : ";
		zone = toInt("zone");
		EOS  = toString("EOS");
		nom  = toString("Nom");
		Ko = toDouble("Ko");
		No = toDouble("No");
		Γo = toDouble("Γo");
		Cvr = toDouble("Cvr");
		θo = toDouble("θo");
		To = toDouble("To");
		Po = toDouble("Po");
		Eo = toDouble("Eo");
		ΔV = toDouble("ΔV");
		dPdT = toDouble("dPdT");
		ρ0 = toDouble("ρ0");
		Sr = toDouble("Sr");
		ur = toDouble("ur");
		ecrire();
	}

	void calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		 const double* v, const double* e ) {
		for (int i = ideb-1; i < ifin; i++) {
			V=v[i];
			E=e[i];
			PotInv(V);
			Potentiel();
			ThetaGamma(V);
			p[i]=Ps+Γρ*(E-Es);
			Pv=PsP+ΓρP*(E-Es)+Γρ*Ps;
			Pe=Γρ;
			c2=-V*V*(Pv-P*Pe);
			c[i]=sqrt(c2);
			double u = (E-Es)/(Cvr*θ)+ur;
			Psi(u);
			T[i]=θ/psiP;
			S[i]=Sr+Cvr*psi;
			g[i]=-V/2 *(-PsS+(E-Es)*Γρ*Γρ*Γρ)/(-PsP+(E-Es)*Γρ*Γρ);
    		}
    	}
    	
	void calculEtatVE(double v,double e){
		V=v;
		E=e;
		PotInv(V);
		Potentiel();
		ThetaGamma(V);
		P=Ps+Γρ*(E-Es);
		Pv=PsP+ΓρP*(E-Es)+Γρ*Ps;
		Pe=Γρ;
		c2=-V*V*(Pv-P*Pe);
		c=sqrt(c2);
		g=-V/2 *(-PsS+(E-Es)*Γρ*Γρ*Γρ)/(-PsP+(E-Es)*Γρ*Γρ);
		double u = (E-Es)/(Cvr*θ)+ur;
		Psi(u);
		T=θ/psiP;
		S=Sr+Cvr*psi;
		Tv = -ur*Γρ*θ+Ps/Cvr;	// pour les mélanges
		Te = 1/Cvr;		// pour les mélanges
		//cout 	<< "	Pv = " << Pv << "	Pe = " << Pe
		//	<< "	Tv = " << Tv << "	Te = " << Te << endl;
	}

	void calculEtatVT(double v,double t){
		V=v;
		PotInv(V);
		Potentiel();
		ThetaGamma(V);
		T=t;
		double u=θ/T;
		E =Es + Cvr*θ*(u-ur) ;
		P=Ps+Γρ*(E-Es);
		Psi(u);
		S=Sr+Cvr*psi;
		Pv=PsP+ΓρP*(E-Es)+Γρ*Ps;
		Pe=Γρ;
		c2=-V*V*(Pv-Pe*P);
		c=sqrt(c2);
		g=-V/2 *(-PsS+(E-Es)*Γρ*Γρ*Γρ)/(-PsP+(E-Es)*Γρ*Γρ);
	}

	void ecrire()
	{ 
		cout <<"EOS ="<< EOS << endl << "	";
		cout <<"Nom ="<< nom << " ,	";
		cout <<"ρ0 ="<< ρ0 << " ,	";
		cout <<"Ko ="<< Ko << " ,	";
		cout <<"No ="<< No << endl << "	";
		cout <<"Γo ="<< Γo << " ,	";
		cout <<"Cvr ="<< Cvr << " ,	";
		cout <<"Eo ="<< Eo << " ,	";
		cout <<"To ="<< To << " ,	";
		cout <<"Po ="<< Po << endl << "	";
		cout <<"ΔV ="<< ΔV << " ,	";
		cout <<"dPdT ="<< dPdT << " ,	";
		cout <<"θo ="<< θo << endl << "	";
		cout <<"Sr ="<< Sr << " ,	";
		cout <<"ur ="<< ur << endl;
	 } 

	//	Potentiel  -> Es,Ps
	void Potentiel(){
	   Es = Ko*ε/ρ0+Eo;
	   Ps = Ko*εp;		//	Ps = -Es'
	   PsP= -Ko*ρ0*εs;	//	Ps'
	   PsS= Ko*ρ0*ρ0*εt;	//	Ps''
	}

	//Potentiel Inversible  -> ε, εp
	void PotInv(double V){
	   double x=1-ρ0*V;
	   εs=exp((No+1)*x);		//	ε''
	   ε= ((εs-1)/(No+1)-x)/(No+1);	//	ε
	   εp= (εs-1)/(No+1);		//	ε'
	   εt= (No+1)*(εs-1);		//	ε'''
	}	

	//  Température de Debye   Gamma*Rho=cste=Γo*ρ0
	void ThetaGamma(double V){
		double x=1-ρ0*V;
		θ= θo*exp(Γo*x);
		Γρ = Γo*ρ0;	
		Γ = Γo*ρ0*V;		//  Γ = -θ'/θ
		ΓρP = 0;
	}

	// fonction Psi  : psi=log <=>  Cv= cste	
	void Psi(double u){
		psi = log(u);
		psiP=1/u;
	}
};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_MGC(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}
