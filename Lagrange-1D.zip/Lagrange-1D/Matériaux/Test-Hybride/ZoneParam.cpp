#include "ZoneParam.h"
#include <string> 
#include <iostream> 

ZoneParam:: ZoneParam() { } 

ZoneParam::ZoneParam(map <string,string> Parametres){ parametres=Parametres; } 

ZoneParam::~ZoneParam(){} 

void ZoneParam::ecrire() { 
	cout << "- Zone  " << parametres.find("zone")->second << "	" ;	
	cout << "EOS = " << parametres.find("EOS")->second << "	"  ;
	cout << "Nom : " << parametres.find("Nom")->second << endl;
//	cout << "	"  ;
//	map<string, string>::iterator it = parametres.begin();
//	int compteur=0;
//	while(it != parametres.end())
//	{
//		cout << it->first <<"="<<it->second << " ,	" ;
//		it++;
//		compteur++;		
//		if ((compteur%4)==3) cout << endl << "	"  ;
//	}
//	cout << endl;
} 
