#ifndef _BOX_ 
#define _BOX_

#include <string> 
#include <iostream> 
#include "ZoneGeom.h" 

using namespace std; 

class Box 
{ 

protected: 

public: 
	int type,i,j,nz,nz1,nz2; 
	BiPoint bip;
	vector <ZoneGeom> zonesG; 

	Box(); 
	
	// Mono
	Box(std::string ij,int Nz); 
	
	// Mixte
	Box(std::string ij,int Nz1,int Nz2,BiPoint Bip); 
	
	// Multi
	Box(std::string ij,vector <ZoneGeom> ZonesG); 

	~Box(); 

	void strToIJ(std::string ij); 
	
	vector <Box> strToBoxes(int nzone,std::string ListBoxes);
	
	void ecrire(); 
} ;

#endif
