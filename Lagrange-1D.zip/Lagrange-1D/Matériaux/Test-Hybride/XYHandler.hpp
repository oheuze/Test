#ifndef _XYHandler_ 
#define _XYHandler_ 

#include <iostream> 
#include <fstream>
#include <map>
#include <math.h>
#include "SAXHandler.hpp"
#include "ParserSAX.hpp"
#include <vector>  
#include "PointXY.h"
#include <dlfcn.h>
using namespace std;

class XYHandler : public SAXHandler {

protected:

public:
	vector <PointXY> pointsXY; 
	std::string mat,nom,element,chaine;
	double Vs,Es; 
	map <string,string> attributs;

	void StartDocument();
	void StartElement(string Element,map <string,string>  Attributs);
	void EndElement(string Element);
	void Characters(string CaracStr);
	void EndDocument();
	
	string 	recupString(std::string motClef,map <string,string> Attr);
	int  	recupInt   (std::string motClef,map <string,string> Attr);
	double 	recupDouble(std::string motClef,map <string,string> Attr);
	string trim(string str);
};

#endif
