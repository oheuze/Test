#ifndef _ZONEPARAM_ 
#define _ZONEPARAM_

#include <string> 
#include <iostream> 
#include <map>  

using namespace std; 

class ZoneParam { 

protected: 

public: 
	ZoneParam(); 
	ZoneParam(map <string,string> Parametres); 
	~ZoneParam (); 
	
	map <string,string> parametres;
	void ecrire(); 
} ; 

#endif
