//	OH-15-05-2023
#include "Mat.h"
#include "LecteurMAT.hpp"

//
// MatBz
//

MatBz::MatBz(const std::string material):Mat(material)
{
	cout << "MatBz : "  <<  material  << endl ;
	parametres["Nom"]= (string) "Bizarrium";
	parametres["Modèle"]= (string) "Bizarrium";
	parametres["Matériau"]= (string) "Bizarrium";
	parametres["EOS"]= (string) "EOS";
	parametres["Ko"]= (string) "1e+11";
	parametres["ρo"]= (string) "10000.";
	parametres["Cvo"]= (string) "1000.";
	parametres["To"]= (string) "300.";
	parametres["εo"]= (string) "0.";
	parametres["Γo"]= (string) "1.5";
	parametres["s"]= (string) "1.5";
	parametres["qnum"]= (string) "-420808950.";
	parametres["rnum"]= (string) "727668333.";
	parametres["den"]= (string) "149411540.";
	cout << " -> " << parametres.size()  << " paramètres. " << endl ;
}

void MatBz::LireDonnees(std::string nomfic){
	
	int posPt = nomfic.find(".");
	int len = nomfic.size();
	string suffixe = nomfic.substr(posPt+1,len) ;
	cout << "Suffixe détecté : " <<  suffixe  << endl ;
	if (suffixe=="xml") 	{
//		LecteurXML* lec= new LecteurXML();
//		lec->LireDonnees(nomfic);
//		parametres= lec->parametres;
	}
	else
	{
		LecteurMAT* lec= new LecteurMAT();
		lec->LireDonnees(nomfic);
		parametres= lec->parametres;
	}
	if (details) AffParamMap();
	InitParam();
	void* EoS_Model = openLib(parametres["EOS"]);
	create_t*  create_EoSModel = createur(EoS_Model);
	//destroy_t* destroy_EoSModel=destroy(EoS_Model);
	eos=create_EoSModel(parametres); 
}

void MatBz::InitParam(){
	cout << "	Initialisation Bz (" << parametres.size() << " paramètres) : " << endl;
	nom	=	toString("Nom");
	modele	=	toString("Modèle");
	materiau=	toString("Matériau");
	//EOS	=	toString("EOS");
	Ko 	=	toDouble("Ko");
	ρo 	=	toDouble("ρo");
	Cvo 	=	toDouble("Cvo");
	To 	=	toDouble("To");
	εo 	=	toDouble("εo");
	Γo 	=	toDouble("Γo");
	s 	=	toDouble("s");
	q 	=	toDouble("qnum")/toDouble("den");
	r 	=	toDouble("rnum")/toDouble("den");
	if (details) cout << "Initialisation correcte." << endl;	
//	Ko=1e+11;	ρo= 10000.;	Cvo= 1000.;	To= 300.;	εo= 0.;	Γo= 1.5;
//	s= 1.5;	q= -420808950./149411540.;	r= 727668333./149411540.;
	ecrire();
}

void MatBz::calculPc(int ideb, int ifin, double* p, double* c, const double* ρ, const double* epsilon)
{
    for (int i = ideb; i <= ifin; i++) {
	double V=1/ρ[i];
	double E=epsilon[i];
	eos->calculEtatVE(V,E);
	p[i]=eos->P;
	c[i]=eos->c;
    }	
	//eos->calculVE(ideb,ifin,p,T,c,g,S,v,epsilon);
}

void MatBz::calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* g, double* S,
	const double* ρ, const double* epsilon)
{
	double v[ifin];
	for (int i = ideb; i <= ifin; i++) {
		v[i]=1.0/ρ[i];
	}	
	eos->calculVE(ideb,ifin,p,T,c,g,S,v,epsilon);
}

void MatBz::calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
		const double* ρ, const double* T)
{
    for (int i = 0; i < N; i++) {
        double x = ρ[i] / ρo - 1;
        double g = Γo * (1 - ρo / ρ[i]);

        double f0 = (1+(s/3-2)*x+q*std::pow(x, 2)+r*std::pow(x, 3))/(1-s*x);
        double f1 = (s/3-2+2*q*x+3*r*std::pow(x, 2)+s*f0)/(1-s*x);

        double epsKo = εo - Cvo*To*(1+g) + 0.5*(Ko/ρo)*std::pow(x, 2)*f0;
        double pKo = -Cvo*To*Γo*ρo + 0.5*Ko*x*std::pow(1+x, 2)*(2*f0+x*f1);
        p[i] = pKo + Γo * ρo * Cvo * ( T[i] - To ) ; 
        epsilon[i]= epsKo + Cvo * T[i] ;   
        
        double f2 = (2*q+6*r*x+2*s*f1)/(1-s*x);
        double pKoprime = -0.5*Ko*std::pow(1+x, 3)*ρo * (2*(1+3*x)*f0 + 2*x*(2+3*x)*f1 + std::pow(x, 2)*(1+x)*f2);
        c[i] = sqrt(Γo * ρo * (p[i] - pKo) - pKoprime) / ρ[i];
    }	
	
}

void MatBz::calculEtatVE(double v,double e){
	V=v;
	E=e;
	eos->calculEtatVE(V,E);
	P=eos->P;
	c=eos->c;
	T=eos->T;
	S=eos->S;
	g=eos->g;
        G=F+P*V;
        γ=0;
        Γ=0;
        ecrireEtat();      
}		
		
void MatBz::ecrire(){
	cout << "Nom : "  << nom ; 
	cout << "	Modèle : "  << modele ; 
	cout << "	Materiau : "  << materiau << endl;
	cout << "	Ko = " << Ko;
	cout << "	ρo = " << ρo;
	cout << "	Cvo = " << Cvo << endl;
	cout << "	To = " << To;
	cout << "	εo = " << εo;
	cout << "	Γo = " << Γo << endl;
	cout << "	s = " << s;
	cout << "	q = " << q;
	cout << "	r = " << r << endl;
}

void* MatBz::openLib(string nomLib){
	string libName="./libEoS_"+nomLib+".so";
	cout << "Chargement de " << libName << " .\n";
	void* library = dlopen(libName.c_str(), RTLD_LAZY);
	if (!library) {
		cerr << "Cannot load library: " << dlerror() << '\n';
	}
    	return library;
}
	
create_t* MatBz::createur(void* library){
    	create_t* create_library = (create_t*) dlsym(library, "create");
    	if (!create_library)
    	{
    		cerr << "Erreur d'ouverture de la fonction (dsym)	create" << endl;
    		exit(0);
    	}	
    	return create_library;
}

destroy_t* MatBz::destructeur(void* library){
    	destroy_t* destroy_library = (destroy_t*) dlsym(library, "destroy");
    	if (!destroy_library)
    	{
    		cerr << "Erreur d'ouverture de la fonction (dsym)	destroy" << endl;
    		exit(0);
    	}	
    	return destroy_library;
}    	








