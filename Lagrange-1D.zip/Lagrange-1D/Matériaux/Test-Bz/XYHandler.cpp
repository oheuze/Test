#include "XYHandler.hpp"
#include <cmath>
	
void  XYHandler::StartDocument(){
	cout << "Début document XY"  << endl;
} 

void  XYHandler::StartElement(string Element,map <string,string> Attributs){
	//cout << "Début Element(" << Element << ")" << endl ;
	if (Element==(string)"Materiau"){ 
		nom= recupString( (string) "nom" ,Attributs); 
		//cout << "Matériau : " << nom  << endl;
	} ;
	if (Element== (string) "PointsXY") { 
		cout << " tag PoinstXY  "  << endl;
	} ;
	
	if (Element== (string) "PointXY") { 
		Vs = recupDouble ( (string) "X", Attributs); 
		Es = recupDouble ( (string) "Y", Attributs);
		PointXY ptXY=PointXY(Vs,Es);
		//ptXY.ecrire();
		pointsXY.push_back(ptXY);
	} ;
}

string  XYHandler::trim(string str){
	while( 	str.find(" ") ==0 || str.find("\n")==0  || 
		str.find("\t")==0  ) str=str.substr(1,str.size());
	string last=str.substr(str.size(),str.size());
	while( last.compare(" ")==0 || last.compare("\n")==0  || last.compare("\t")==0  ) 		
			str=str.substr(0,str.size()-1);
	return str;
}


string XYHandler::recupString(string motClef,map <string,string> Attributs) { 
	string valStr; 
	try {
		valStr = Attributs.at(motClef);
	}
	catch(const std::out_of_range& oor) {
	    cout << motClef << "	non renseigné. " << endl;
	}
	string valeur = valStr.substr(0,valStr.size());
	return valeur; 
} 

int XYHandler::recupInt(string motClef,map <string,string> Attributs) { 
	string valStr; 
	try {
		valStr = Attributs.at(motClef);
	}
	catch(const std::out_of_range& oor) {
	    cout << motClef << "	non renseigné. " << endl;
	}
	int valeur = (int) stoi( valStr.substr(0,valStr.size()) );  
	return valeur; 
} 

double XYHandler::recupDouble(string motClef,map <string,string> Attributs) { 
	string valStr; 
	try {
		valStr = Attributs.at(motClef);
	}
	catch(const std::out_of_range& oor) {
	    cout << motClef << "	non renseigné. " << endl;
	}
	double valeur = stod(valStr.substr(0,valStr.size())); 
	return valeur; 
}

void  XYHandler::EndElement(string Element){
	//cout << "Fin Element   : " << Element  << endl;
}

void XYHandler::Characters(string CaracStr){
	argument = trim(CaracStr);	
	if ( argument.size()>0 ) cout << "#	Argument : " << argument  << endl;
}

void  XYHandler::EndDocument(){	
	cout << "Fin  document XY "  << endl;
}

