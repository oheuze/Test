//	OH-2-10-2023
#include "Mat.h"
#include "LecteurMAT.hpp"

//
// MatGP
//

MatGP::MatGP(const std::string material):Mat(material)
{
	cout << "MatGP : "  <<  material  << endl ;
}

void MatGP::LireDonnees(std::string nomfic){
	
	int posPt = nomfic.find(".");
	int len = nomfic.size();
	string suffixe = nomfic.substr(posPt+1,len) ;
	cout << "Suffixe détecté : " <<  suffixe  << endl ;
	if (suffixe=="xml") 	{
		cout << "Lecteur XML : à écrire "  << endl ;
//		LecteurXML* lec= new LecteurXML();
//		lec->LireDonnees(nomfic);
//		parametres= lec->parametres;
	}
	else
	{
		LecteurMAT* lec= new LecteurMAT();
		lec->LireDonnees(nomfic);
		parametres= lec->parametres;
	}
	InitParam();
	void* EoS_Model = openLib(parametres["EOS"]);
	create_t*  create_EoSModel = createur(EoS_Model);
	//destroy_t* destroy_EoSModel=destroy(EoS_Model);
	eos=create_EoSModel(parametres); 
}
	
void MatGP::InitParam(){
	cout << "	Initialisation GP (" << parametres.size() << " paramètres) : " << endl;
	nom	=	toString("Nom");
	modele	=	toString("Modèle");
	materiau=	toString("Matériau");
	R 	=	toDouble("R");
	γ 	=	toDouble("γ");
}
	
void MatGP::ecrire(){
	cout << "MatGP : ecrire" << endl ;
}

void MatGP::calculPc(int ideb, int ifin, double* p, double* c, const double* rho, const double* epsilon)
{
	for (int i = ideb; i <= ifin; i++) {
	        p[i] = (γ - 1.) * rho[i] * epsilon[i];
        	c[i] = sqrt(γ * p[i] / rho[i]);
        }	
}

void MatGP::calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* g, double* S,
	const double* rho, const double* epsilon)
{
	for (int i = ideb; i <= ifin; i++) {
		eos->calculEtatVE(1/rho[i],epsilon[i]);
		p[i]=eos->P;
		c[i]=eos->c;
		T[i]=eos->T;
        	S[i]=eos->S;
        	g[i]=eos->g;
        }	
}

void MatGP::calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
		const double* rho, const double* T)
{
	for (int i = 0; i < N; i++) {
	        p[i] = rho[i] * R * T[i];
        	c[i] = sqrt(γ * p[i] / rho[i]);
        	epsilon[i] = R * T[i] /  (γ - 1.);
        }	
}

void MatGP::calculEtatVE(double v,double e){
	V = v;
	E = e; 
	P = (γ - 1.)* E/V;
        c = sqrt(γ * P*V);
        T = (v - 1.) *E / R / V;
       	g= (γ + 1.)/2;
       	H=E+P*V;
       	F=E-T*S;
       	G=F+P*V; 
       	Γ=+1;
       	// à compléter
       	S=0; 
        ecrireEtat();       
}	


void* MatGP::openLib(string nomLib){
	string libName="./Matériaux/libEoS_"+nomLib+".so";
	cout << "Chargement de " << libName << " .\n";
	void* library = dlopen(libName.c_str(), RTLD_LAZY);
	if (!library) {
		cerr << "Cannot load library: " << dlerror() << '\n';
	}
    	return library;
}
	
create_t* MatGP::createur(void* library){
    	create_t* create_library = (create_t*) dlsym(library, "create");
    	if (!create_library)
    	{
    		cerr << "Erreur d'ouverture de la fonction (dsym)	create" << endl;
    		exit(0);
    	}	
    	return create_library;
}

destroy_t* MatGP::destructeur(void* library){
    	destroy_t* destroy_library = (destroy_t*) dlsym(library, "destroy");
    	if (!destroy_library)
    	{
    		cerr << "Erreur d'ouverture de la fonction (dsym)	destroy" << endl;
    		exit(0);
    	}	
    	return destroy_library;
}    	

