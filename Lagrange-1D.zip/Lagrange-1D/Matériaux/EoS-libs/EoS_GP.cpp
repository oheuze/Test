#ifndef _EoS_GP_H 
#define _EoS_GP_H 
#include "EoS.hpp"
#include <cmath>

class EoS_GP : public EoS {

protected :

public: 
	EoS_GP(map <string,string> Parametres){	
		parametres= Parametres;  
		cout << "	Initialisation EoS GP (" << parametres.size() << " paramètres) : ";
		nom	=toString("Nom");
		R	=toDouble("R");
		γ 	=toDouble("γ");
		ecrire();
	}
	
	void calculEtatVE(double v,double e) {
		V=v;
		E=e;
		P= (γ-1)*E/V;
		T= (γ-1)*E/R;
		S= R/(γ-1)*(log(P)+γ*log(V));
		c2= γ*P*V;
		c=sqrt(c2);
		g= (γ+1)/2;	
    	}
    		
	void calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		const double* v, const double* e) {
		for (int i = ideb; i <= ifin; i++) {
			p[i]= (γ-1)*e[i]/v[i];
			T[i]= (γ-1)*e[i]/R;
			S[i]= R/(γ-1)*(log(p[i])+γ*log(v[i]));
			c[i]=sqrt(γ*p[i]*v[i]);	
			g[i]=(γ+1)/2;	
    		}
    	}
	
	void calculEtatVT(double v,double t) {
		V=v;
		T=t;
		P= (γ-1)*E/V;
		E= R*T/(γ-1);
		S= R/(γ-1)*(log(P)+γ*log(V));
		c2= γ*P*V;
		c=sqrt(c2);	
    	}
    	
	void ecrire() {   
		cout << "	nom = " << nom ;
		cout << "	R= " << R ;
		cout << ",	γ= " << γ ;
		cout << "\n";
	}    	
};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_GP(Parametres);	}
extern "C" void destroy(EoS* p){	delete p;	}

#endif
