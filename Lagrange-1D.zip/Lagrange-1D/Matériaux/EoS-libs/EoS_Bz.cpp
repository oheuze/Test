﻿#include "EoS.hpp"
#include <cmath>
#include <iostream>

//  OH-15-05-2023

//  O. Heuzé, S. Jaouen, H. Jourdren, "Dissipative issue of high-order shock capturing schemes with non-convex equations of state", JCP 2009)

class EoS_Bz : public EoS {	

protected :
	
public:	
	// paramètres EoS_Bz	
	double 	ρo, Ko, To, Γo, Cvo, εo, So, qnum, rnum, den, q, r, s;
	//	ρo(10000.) , Ko(1e+11) , Cvo(1000.) , To(300.) , εo(0.) , Γo(1.5)
	//	s(1.5) , q(-420808950. / 149411540.) , r(727668333. / 149411540.)
	
	// grandeurs EoS_Bz	
	double Es,Ps,ε;
	
	EoS_Bz(map <string,string> Parametres){		
		parametres= Parametres;  
		cout << "	Initialisation EoS_Bz  ("<< parametres.size() << " paramètres ) : ";
		EOS = toString("EOS");
		nom = toString("Nom");
		ρo  = toDouble("ρo");
		Ko  = toDouble("Ko");
		Γo  = toDouble("Γo");
		Cvo = toDouble("Cvo");
		To  = toDouble("To");
		εo  = toDouble("εo");
		qnum= toDouble("qnum");
		rnum= toDouble("rnum");
		den = toDouble("den");
		q   = qnum/den;
		r   = rnum/den;
		s   = toDouble("s");
		So=0;
		ecrire();
	}

	void calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		const double* v, const double* e ) {
		for (int i = ideb; i <= ifin; i++) {
			V=v[i];
			E=e[i];
			double x = 1 / ρo / V - 1;	
			double ε = Γo * (1 - ρo * V);	//  formula (4b)
			double x2=x*x;
			double x3=x2*x;
			double f0 = (1+(s/3-2)*x+q*x2+r*x3)/(1-s*x);	//  formula  (15b)
			double f1 = (s/3-2+2*q*x+3*r*x2+s*f0)/(1-s*x);	//  formula  (16a)
			double εKo = εo - Cvo*To*(1+ε) + 0.5*(Ko/ρo)*x2*f0;	//  Formula (15a) 
			double xp12=(1+x)*(1+x);
			double pKo = -Cvo*To*Γo*ρo + 0.5*Ko*x*xp12*(2*f0+x*f1);	//  Formula (17a) 
			p[i] = pKo + Γo * ρo * (E - εKo);	//	Formula (5b) 
			double f2 = (2*q+6*r*x+2*s*f1)/(1-s*x);		//	formula  (16b)
			double f3 = (6*r+3*s*f2)/(1-s*x);	//	formula (16c)
			double xp13=xp12*(1+x);
			// Pk'[V] == -Ko  ρo (1 + x)^3 ( 2(1+3x) f0[x] + 2x(2+3x) f1 + x^2(1 + x) f2)/2
			double pKoP = -0.5*Ko*ρo*xp13 * ( 2*(1+3*x)*f0 + 2*x*(2+3*x)*f1 + x2*(1+x)*f2 );	//  Formula (17b)
		    	c[i] = V*sqrt(Γo * ρo * (p[i] - pKo) - pKoP);	//	Formula (8)
			T[i] = (E-εKo)/Cvo;
			S[i] = So-Cvo*ε+Cvo*log((E-εKo)/(Cvo*To));
			double xp14=xp13*(1+x);
			// Pk''[V] == 1/2 Ko  ρo^2 (1 + x)^4 (12 (1 + 2 x) f0[x] + 6 (1 + 6 x + 6 x^2) f1 + x (1 + x) (6 (1 + 2 x) f2 + x (1 + x) f3))
			double pKoS = 0.5*Ko*std::pow(ρo,2)*xp14 * ( 12*(1+2*x)*f0 + 6*(1+6*x+6*x2)*f1 + 6*x*(1+x)*(1+2*x)*f2 + x2*xp12*f3);	//  Formula (17c)
			double ρc2 = Γo * ρo * (p[i] - pKo) -pKoP ;
			g[i] = 0.5*V/ρc2*(pKoS+std::pow((Γo*ρo), 2)*(p[i]-pKo)); //	Formula (8) + (11)
		}
    }
		
	void calculEtatVE(double v,double e){
		V=v;
		E=e;
		double x = 1 / ρo / V - 1;	
		double ε = Γo * (1 - ρo * V);	//  formula (4b)
		double x2=x*x;
		double f0 = (1+(s/3-2)*x+q*x2+r*std::pow(x, 3))/(1-s*x);	//  formula  (15b)
		double f1 = (s/3-2+2*q*x+3*r*x2+s*f0)/(1-s*x);	//  formula  (16a)
		double εKo = εo - Cvo*To*(1+ε) + 0.5*(Ko/ρo)*x2*f0;	//  Formula (15a) 
		double xp12=(1+x)*(1+x);
		double pKo = -Cvo*To*Γo*ρo + 0.5*Ko*x*xp12*(2*f0+x*f1);	//  Formula (17a) 
		P = pKo + Γo * ρo * (E - εKo);	//	Formula (5b) 
		double f2 = (2*q+6*r*x+2*s*f1)/(1-s*x);		//	formula  (16b)
		double f3 = (6*r+3*s*f2)/(1-s*x);	//	formula (16c)
		double xp13=xp12*(1+x);
			// Pk'[V] == -Ko  ρo (1 + x)^3 ( 2(1+3x) f0[x] + 2x(2+3x) f1 + x^2(1 + x) f2)/2
		double pKoP = -0.5*Ko*ρo*xp13 * ( 2*(1+3*x)*f0 + 2*x*(2+3*x)*f1 + x2*(1+x)*f2 );	//  Formula (17b)
		c = V*sqrt(Γo * ρo * (P - pKo) - pKoP);	//	Formula (8)
		T = (E-εKo)/Cvo;
		S = So-Cvo*ε+Cvo*log((E-εKo)/(Cvo*To));
		double xp14=xp13*(1+x);
		// Pk''[V] == 1/2 Ko  ρo^2 (1 + x)^4 (12 (1 + 2 x) f0[x] + 6 (1 + 6 x + 6 x^2) f1 + x (1 + x) (6 (1 + 2 x) f2 + x (1 + x) f3))
		double pKoS = 0.5*Ko*std::pow(ρo,2)*xp14 * ( 12*(1+2*x)*f0 + 6*(1+6*x+6*x2)*f1 + 6*x*(1+x)*(1+2*x)*f2 + x2*xp12*f3);	//  Formula (17c)
		double ρc2 = Γo * ρo * (P - pKo) -pKoP ;
		g = 0.5*V/ρc2*(pKoS+std::pow((Γo*ρo), 2)*(P-pKo)); //	Formula (8) + (11)
	}

	void calculEtatVT(double v,double t){
		V = v;
		T = t;
		P=0;
		S=0;
		E=0;
		c=0;
	}

	void ecrire()
	{ 
		//  	ρo, Ko, To, Cvo , εo, So, Γo, q, r, s;
		cout <<"EOS ="<< EOS << endl << "	";
		cout <<"Nom ="<< nom << " ,	";
		cout <<"ρo ="<< ρo << " ,	";
		cout <<"Ko ="<< Ko << " ,	";
		cout <<"To ="<< To << endl << "	";
		cout <<"Γo ="<< Γo << " ,	";
		cout <<"Cvo ="<< Cvo << " ,	";
		cout <<"εo ="<< εo << " ,	";
		cout <<"q ="<< q << " ,	";
		cout <<"r ="<< r << " ,	";
		cout <<"s ="<< s <<  endl;
	 } 
};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_Bz(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}
