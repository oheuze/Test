include("foncsXML.jl")
# Entrées		
 test       =  "MieGru"	
 nom	     =  "exemple"	
 scheme     =  "Godunov"	
 ieee_bits  =  64	
 nbcell     =  1000	
 maxcycle   =  500000	
 riemann    =  "acoustic"	
 iterations =  4	
 nghost     =  2	
 silent     =  0	
 maxtime    =  8.0e-5	
 cfl        =  0.95	
 Dt         =  1.0e-12		
 xmin       =  0.0	
 bcDeb      =  "Libre"	
 bcFin      =  "Libre"	

xmin=0.
xmax=1.
xseuil=0.5

nomdeb = "Projectile"
ρdeb = 7287.0
udeb = 1000.
edeb = 0.
	
nomfin = "Cible"
ρfin = 7287.0
ufin = 0.
efin = 0.

modele="MieGru"
sigle="Snβ"

#	remplacer les " par des dièses dans Parametres
#  	EOS à compléter dans le fichier XML
parametres="ParametresMieGru(#Sn-β#,7287.0,53597000000.0,4.996,2.270,0.0,
		250.0,210.0,1.2,0.0,-38.2875,#Réf: Pour Thèse#)"

proj =Milieu("Projectile",ρdeb,udeb,edeb,xseuil,nbcell/2,modele,sigle)
cible=Milieu("Cible"     ,ρfin,ufin,efin,xmax,nbcell/2,modele,sigle)
casTest=Cas(nom,test,scheme,ieee_bits,maxcycle,riemann,iterations,
	nghost,silent,maxtime,cfl,Dt,xmin,bcDeb,bcFin,[proj,cible])

EcriXML(casTest,nom*".xml")

