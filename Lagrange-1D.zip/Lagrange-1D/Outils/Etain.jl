# OH 3/06/2023
using Plots, DataFrames
include("./MateriauJ.jl")
include("./Thermo.jl")

SnL = Materiau.MGC("Sn-L.mat")
Snγ = Materiau.MGC("Sn-γ.mat")
Snβ = Materiau.MGC("Sn-β.mat")
Materiau.LireDonnees(Snβ,"Sn-β.mat")
Materiau.LireDonnees(Snγ,"Sn-γ.mat")
Materiau.LireDonnees(SnL,"Sn-L.mat")
Materiau.InitParam(Snβ)
Ko=Materiau.getVal(Snβ,"Ko")
etatA=Etat(Snβ,"A", 1. / 130.e-6,1000000.)
etatA.ρ
N=4
p = zeros(Float64, N);
c = zeros(Float64, N);
T = zeros(Float64, N);
g = zeros(Float64, N);
S = zeros(Float64, N);
ρ=[7287.0,8307.78,7227.42,7571.96 ]
ε = [0, 51821.2,46660.4,59357.9]
Materiau.calculEtats(Snβ,0,N-1,p,c,T,g,S,ρ,ε)
etatsβ= DataFrame(ρ=ρ,E=ε,P=p,T=T,c=c,S=S,df=g)

ρ=[ 12884.4 , 8465.82,12618.8, 7674.96 ]
ε = [ 1727490.0 , 87301.3 , 2113710.0, 90466.3 ]
Materiau.calculEtats(Snγ,0,N-1,p,c,T,g,S,ρ,ε)
etatsγ= DataFrame(ρ=ρ,E=ε,P=p,T=T,c=c,S=S,df=g)

function Hugoniot(Mat,Vecρ,Po,ρo,Eo)
	N=   length(Vecρ)
        println("Hugoniot (Mie-Grüneisen) :")
        println("Pole : Po=",Po,"  ρo=",ρo,"   Eo=",Eo)
        println(N," points :")
        Vecε0  = zeros(Float64, N);
	Vecp0 = zeros(Float64, N);
	Vecc  = zeros(Float64, N);
	VecT  = zeros(Float64, N);
	Vecg  = zeros(Float64, N);
	VecS  = zeros(Float64, N);
	Materiau.calculEtats(Mat,0,N-1,Vecp0,Vecc,VecT,Vecg,VecS,Vecρ,Vecε0)
	etats0= DataFrame(ρ=Vecρ,E=Vecε0,P=Vecp0,T=VecT,c=Vecc,S=VecS,df=Vecg)
	c0=Vecc[1]
	dε=1.E6
	Vecε = ones(Float64, N) .* dε
	Vecp = zeros(Float64, N)
	Materiau.calculEtats(Mat,0,N-1,Vecp,Vecc,VecT,Vecg,VecS,Vecρ,Vecε)
	etats1= DataFrame(ρ=Vecρ,E=Vecε,P=Vecp,T=VecT,c=Vecc,S=VecS,df=Vecg)
	VecPh = ones(Float64, N);
	VecEh = ones(Float64, N);
	VecD = ones(Float64, N);
	Vecu = ones(Float64, N);
	for i in 3:N
		dV= 1.0 / ρo - 1.0 / Vecρ[i]
		Γρ=(Vecp[i]-Vecp0[i])/dε
		den=1.0 -Γρ*dV/2
		VecPh[i]=(Vecp0[i]+Γρ*(Eo+Po*dV/2))/den
		VecEh[i]=(Eo+(Vecp0[i]+Po)*dV/2)/den
		dP=VecPh[i]-Po
		println(dP, "# ",dV)
		if ( dV>0 ) 
			VecD[i]=sqrt(dP/dV)/ρo 
		else 
			VecD[i]=c0
		end
		Vecu[i]=sqrt(dP*dV)
		GPa=10^9
        	println("ρ = ",Vecρ[i]," kg/m3	Ph= ",VecPh[i]/GPa," GPa	Eh=",VecEh[i]," D=",VecD[i]," m/s	u=",Vecu[i],"  m/s")
	end 
	etatsH= DataFrame(Ph=VecPh,Eh=VecEh,D=VecD,u=Vecu)
        return VecPh,VecEh,VecD,Vecu          
end

dataUsUp = [[0., 2755.], [304., 3273.], [418., 3299.], [451., 3263.], 
	[577., 3361.], [642., 3482.], [645., 3476.], [677., 3514.], 
	[693., 3524.], [767., 3658.], [896., 3956.], [1073., 4102.], 
	[1161., 4382.], [1171., 4309.], [1201., 4292.], [1260., 4500.], 
	[1361., 4587.], [1456., 4755.], [1465., 4766.], [1493., 4793.], 
	[1665., 5239.], [1669., 5083.], [1734., 5331.], [1926., 5527.], 
	[1929., 5504.], [1933., 5481.], [1940., 5458.], [2002.0, 5661.], 
	[2044., 5717.], [2082., 5752.], [2461., 6193.], [2564., 6500.], 
	[2751., 6721.], [2764., 6626.], [2770., 6664.], [2780., 6765.], 
	[2859., 6849.], [2893., 6858.], [2942., 6935.], [3038., 7068.], [3118., 7236.]];
	
uPexp = [ dataUsUp[i][1] for i=1:length(dataUsUp) ];
uSexp = [ dataUsUp[i][2] for i=1:length(dataUsUp) ];

Po = 10^5;
ρo = Materiau.getVal(Snβ,"ρ0")
Eo = Materiau.getVal(Snβ,"Eo");

# Vérification  de	Ph==P(V,Eh)
# ph = zeros(Float64, nβ)
# Materiau.calculEtats(Snβ,....,ph,c,T,vecρβ,Eh)
# ph

nβ=7
vecρβ=[ 7400 + 100.0 *i  for i=1:nβ ] 
(Phβ,Ehβ,Dβ,uβ)=Hugoniot(Snβ,vecρβ,Po,ρo,Eo);

PEDuβ=[[7400, 8.5730E8, 898.26,42.38,2775.69],
       [7500., 1.6610E9, 3236.75,80.458, 2833.034],
       [7600., 2.508E9, 7089.625,  119.0766, 2891.3181],
       [7700., 3.4025E9, 12522.455, 158.2558, 2950.532],
       [7800., 4.344E9, 19603.82840, 198.0092, 3010.6667],
       [7899.9, 5.3350E9, 28405.13, 238.34906, 3071.7090],
       [8000., 6.37747E9, 39000.433, 279.286, 3133.647]
       ]

# Hugoniot  phase γ  
nγ=7
vecργ=[ 8700 + 100.0 *i  for i=1:nγ ] 

N=nγ
Vecρ=vecργ
        Vecε0  = zeros(Float64, N);
	Vecp0 = zeros(Float64, N);
	Vecc  = zeros(Float64, N);
	VecT  = zeros(Float64, N);
	Vecg  = zeros(Float64, N);
	VecS  = zeros(Float64, N);
	Materiau.calculEtats(Snγ,0,N-1,Vecp0,Vecc,VecT,Vecg,VecS,Vecρ,Vecε0)
	etats0= DataFrame(ρ=Vecρ,E=Vecε0,P=Vecp0,T=VecT,c=Vecc,S=VecS,df=Vecg) 
	println(etats0)
	c0=Vecc[1]
	dε=1.E6
	Vecε = ones(Float64, nγ) .* dε
	Vecp = zeros(Float64, nγ)
	Materiau.calculEtats(Snγ,0,nγ-1,Vecp,Vecc,VecT,Vecg,VecS,vecργ,Vecε)
	etats1= DataFrame(ρ=vecργ,E=Vecε,P=Vecp,T=VecT,c=Vecc,S=VecS,df=Vecg)
	println(etats1)
	
	VecPh = ones(Float64, N);
	VecEh = ones(Float64, N);
	VecD = ones(Float64, N);
	Vecu = ones(Float64, N);
	for i in 3:N
		dV= 1.0 / ρo - 1.0 / Vecρ[i]
		Γρ=(Vecp[i]-Vecp0[i])/dε
		den=1.0 -Γρ*dV/2
		VecPh[i]=(Vecp0[i]+Γρ*(Eo+Po*dV/2))/den
		VecEh[i]=(Eo+(Vecp0[i]+Po)*dV/2)/den
		dP=VecPh[i]-Po
		println(dP, "# ",dV)
		if ( dV>0 ) 
			VecD[i]=sqrt(dP/dV)/ρo 
		else 
			VecD[i]=c0
		end
		Vecu[i]=sqrt(dP*dV)
		GPa=10^9
        	println("ρ = ",Vecρ[i]," kg/m3	Ph= ",VecPh[i]/GPa," GPa	Eh=",VecEh[i]," D=",VecD[i]," m/s	u=",Vecu[i],"  m/s")
	end 
	etatsH= DataFrame(Ph=VecPh,Eh=VecEh,D=VecD,u=Vecu)

(Phγ,Ehγ,Dγ,uγ)=Hugoniot(Snγ,vecργ,Po,ρo,Eo);
PEDuγ=[
        [8800, 1.35885*10^10, 160306., 566.226, 3293.32],
        [8900., 1.49564*10^10, 185991., 609.903, 3365.24],
        [9000., 1.63852*10^10, 213988., 654.198, 3437.12],
        [9100., 1.78766*10^10, 244378., 699.11, 3509.05],
        [9200., 1.94317*10^10, 277242., 744.637, 3581.11],
        [9300., 2.10521*10^10, 312664., 790.776, 3653.36],
        [9400., 2.2739*10^10, 350723., 837.524, 3725.85]
       ]

# Hugoniot  phase Liquide
nL=30
vecρL=[ 10600 + 100.0 *i  for i=1:nL ]
(PhL,EhL,DL,uL)=Hugoniot(SnL, vecρL,Po,ρo,Eo);

PEDuL=[
        [10800, 5.52346*10^10, 1.23278*10^6, 1570.21, 4827.3],
        [10900., 5.80181*10^10, 1.31955*10^6, 1624.53, 4901.02],
        [11000., 6.08823*10^10, 1.41008*10^6, 1679.33, 4975.14],
        [11100., 6.38279*10^10, 1.50444*10^6, 1734.61, 5049.63],
        [11200., 6.68559*10^10, 1.6027*10^6, 1790.36, 5124.48],
        [11300., 6.99671*10^10, 1.70493*10^6, 1846.58, 5199.69],
        [11400., 7.31622*10^10, 1.81118*10^6, 1903.25, 5275.24]
       ]
       
Materiau.calculEtatVE(SnL,1/13600,5.291527555979507e6)
#	Figure D(u)
println(" Affichage de la courbe D(u) ")
scatter(uPexp,uSexp,xlabel="u(m/s)",ylabel="D(m/s)",label="exp")
plot!(uβ,Dβ,label="β")       
plot!(uγ,Dγ,label="γ")       
plot!(uL,DL,label="L")







