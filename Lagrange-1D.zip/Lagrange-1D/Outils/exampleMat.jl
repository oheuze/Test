# OH 12/05/2023

include("./MateriauJ.jl")

gp = Materiau.GP("Gaz Parfait")
Materiau.InitParam(gp)
Materiau.setParam(gp,"Gamma","1.4")

N = 10
Sod_ρ0_left = 1.
Sod_E0_left = 1.
Sod_u0_left = 0.

ρ = ones(Float64, N) .* Sod_ρ0_left
E = ones(Float64, N) .* Sod_E0_left
u = ones(Float64, N) .* Sod_u0_left

ε = ones(Float64, N)

p = zeros(Float64, N)
c = zeros(Float64, N)
T = zeros(Float64, N)
S = zeros(Float64, N)
g = zeros(Float64, N)

Materiau.calculEtats(gp,1,N,p,c,T,S,g,ρ,ε)
psod=deepcopy(p)
Tsod=deepcopy(T)
csod=deepcopy(c)

#mgc = Materiau.MGC("Sn-β.mat")
#Materiau.InitParam(mgc)
#Ko=Materiau.getVal(mgc,"Ko")
#Materiau.LireDonnees(mgc,"Sn-β.mat")

hyb = Materiau.Hybride("Hybride")
Materiau.LireDonnees(hyb,"Sn-thèse-24x35.xml")
Materiau.InitParam(hyb)

bz = Materiau.Bizarrium("Bz")
Materiau.setParam(bz,"GammaBz","1.4")
Materiau.InitParam(bz)

ρ_Sn = 7500
ε_Sn = 0
ρ = ones(Float64, N) .* ρ_Sn
ε = ones(Float64, N) .* ε_Sn
Materiau.calculEtats(hyb,1,N,p,c,T,S,g,ρ,ε)
pmgc=deepcopy(p)
Tmgc=deepcopy(T)
cmgc=deepcopy(c)




