function GetZonesMixtes()
           nbMixte=0;
           listZ=Matrix{Int64}[];
           for i=1:nV
               for j=1:nE
                   if typeof(grille[i,j])==Matrix{Int64}
                          nbMixte=nbMixte+1
                          println(nbMixte,"  (",i," , ",j,")   ",grille[i,j])
                          push!(listZ,grille[i,j])
                   end
               end
           end
           return listZ
       end
       
function GetZonesMulti()
           nbMulti=0;
           listZ=Vector{Int64}[];
           for i=1:nV
               for j=1:nE
                   if typeof(grille[i,j])==Vector{Int64}
                          nbMulti=nbMulti+1
                          println(nbMulti,"  (",i," , ",j,")   ",grille[i,j])
                          push!(listZ,grille[i,j])
                   end
               end
           end
           return listZ
end
      
function GetMixte()
           nbMixte=0;
           ListSegs=Matrix{Float64}[];
           for i=1:nV
               for j=1:nE
                   if typeof(geom[i,j])==Matrix{Float64}
                          nbMixte=nbMixte+1
                          println(nbMixte,"  (",i," , ",j,")   ",geom[i,j])
                          push!(ListSegs,geom[i,j])
                   end
               end
           end
           return ListSegs
       end

function GetMulti()
	nbMulti=0;
	ListMultiSegs=[]
	for i=1:nV
               for j=1:nE
                   if typeof(geom[i,j])!=Matrix{Float64} && typeof(geom[i,j])!=String
                       nbMulti=nbMulti+1
                       println(nbMulti,"  (",i," , ",j,")   ",geom[i,j])
                       push!(ListMultiSegs,geom[i,j])
                   end
               end
        end               
	return ListMultiSegs
end
       
function GrilleToStr(Grille)
               listGrille=Set(Grille)
               GrilleToStr=[];
               GrilleInv=[];
               i=0;
               for elt in listGrille
                   i=i+1;
                   push!(GrilleToStr,elt=>string(Char(96+i)))
                   push!(GrilleInv,string(Char(96+i))=>elt)
               end;
               DictGrille=Dict(GrilleToStr)
               DictInv=Dict(GrilleInv)
               GrilleStr="";for j=1:nE
                   for i=1:nV
                       GrilleStr=GrilleStr*DictGrille[grille[i,nE+1-j]]
                   end
                   GrilleStr=GrilleStr*"\n"
               end
               println(DictInv);println(GrilleStr)
               return DictInv,GrilleStr
end	

function GrilleToStr(Grille)
                      listGrille=Set(Grille)
                      GrilleToStr=[];
                      GrilleInv=[];
                      i=0;
                      for elt in listGrille
                          i=i+1;
                          if typeof(elt)==Int64 && 0<=elt<=9 char=string(elt) else char=string(Char(96+i)) end
                          if typeof(elt)==String && length(elt)==1 char=elt end
                          push!(GrilleToStr,elt=>char)
                          push!(GrilleInv,char=>elt)
                      end;
                      DictGrille=Dict(GrilleToStr)
                      DictInv=Dict(GrilleInv)
                      GrilleStr="";for j=1:nE
                          for i=1:nV
                              GrilleStr=GrilleStr*DictGrille[grille[i,nE+1-j]]
                          end
                          GrilleStr=GrilleStr*"\n"
                      end
                      println(DictInv);println(GrilleStr)
                      return DictInv,GrilleStr
end

function StrToGrille(dict,GrilleStr)
               len=length(GrilleStr)
               GrilleChr=Vector{Char}(GrilleStr)
               ii=len;nI=0
               while ii>=1  
                       if Int(GrilleChr[ii])==10 nI=ii-1 end;
                       ii=ii-1
               end
               nJ=Int(length(GrilleStr)/(nI+1));
               println(nI," , ",nJ);Grille=Array{Any}(undef,nI,nJ);
               for i=1:nI
                   for j=1:nJ
                     Grille[i,j]=dict[SubString(GrilleStr,i+(nJ-j)*(nI+1),i+(nJ-j)*(nI+1))]
                   end
               end    
               return Grille
end

listSegs = GetMixte()
listMultiSegs = GetMulti()
listZMixtes = GetZonesMixtes()       
listZMulti  = GetZonesMulti() 
println("
listZMixtes = GetZonesMixtes()	\n
listZMulti  = GetZonesMulti() 	\n
listSegs = GetMixte()		\n
listMultiSegs = GetMulti()	\n
") 

