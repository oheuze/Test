import Pkg; 
Pkg.activate("../GP")
using GP

gp53 = GP.ParametresGP("gp 5/3",5/3,"");

#	-t Leblanc --cells 800 --cfl 0.06

if maxtime == 0
	global maxtime = 6
end

if cfl == 0
	global cfl = 0.25
end
	
global bcDeb = bcMur;
global bcFin = bcMur;
	
modeleEOS = "GP"
paramEOS = gp53
	
gamma = 5/3
	
xmin = 0.
xmax = 9.
xseuil = 3
	
nomdeb = "HP"
ρdeb = 1.0
udeb = 1.
edeb = 0.1
	
nomfin = "BP"
ρfin = 0.001
ufin = 0.
efin = 1e-7

gauche=Milieu("Gauche",ρdeb,udeb,edeb,xseuil,nbcell/2,"GP75")
droit=Milieu("Droit",ρfin,ufin,efin,xmax,nbcell/2,"GP75")
casTest=Cas(test,test,scheme,ieee_bits,maxcycle,riemann,iterations,
	nghost,silent,maxtime,cfl,Dt,xmin,bcDeb,bcFin,[gauche,droit])

hp=Milieu("HP",  1.0, 1.0,  0.1,3.0,300,"GP53")
bp=Milieu("BP",0.001, 0.0, 1e-7,9.0,600,"GP53")
casLeblanc=Cas("Leblanc","Leblanc","Godunov",64,500000,
	"three-term_acoustic",4,2,0,6.0,0.06,1.0e-12,0.0,"Mur","Mur",[hp,bp])
	
EcriCas(casLeblanc)
ExpandCas(casLeblanc)

