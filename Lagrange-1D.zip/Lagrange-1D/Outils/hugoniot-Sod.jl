#test="Sod"
#include("../Init-Lag-2.jl")
#gp75
using Plots

println(" Hugoniot :")
gauche=casTest.milieux[1]
#println(gauche)
ρdeb=gauche.ρ
udeb=gauche.u
edeb=gauche.e
xseuil=gauche.xmax
nomdeb=gauche.Nom
#pdeb=GP.Pρe(ρdeb,edeb,gp75)

droit=casTest.milieux[2]
#println(droit)
ρfin=droit.ρ
ufin=droit.u
efin=droit.e
xmax=droit.xmax
nomfin=droit.Nom
#pfin=GP.Pρe(ρfin,efin,gp75)

deb=GP.Etat("Deb",ρdeb,edeb,gp75)
pdeb=deb.P
fin=GP.Etat("Fin",ρfin,efin,gp75)
pfin=fin.P
pole=GP.Etat("pole",ρfin,efin,gp75)
AffEtat(pole)
GP.Ph(0.2,pole,gp75)
GP.Eh(0.2,pole,gp75)
ptHug=GP.EtatH("h1",0.2,pole,gp75)
#Ph,Eh,u,D=GP.Hugoniot(0.2,pole,gp75)

rh=[];ph=[];rs=[];ps=[];us=[];uh=[];vh=[];vs=[];eh=[];es=[];cs=[];
push!(rs,ρdeb);push!(rh,ρfin);
push!(ps,pdeb);push!(ph,pfin);
push!(cs,sqrt(gp75.γ*pdeb/ρdeb));
push!(us,udeb);push!(uh,ufin);
push!(vs,1/ρdeb);push!(vh,1/ρfin);
push!(es,pdeb/ρdeb/(gp75.γ-1));
push!(eh,pfin/ρfin/(gp75.γ-1));
for i=1:30
       push!(ph,GP.Ph(rh[i],fin,gp75))
       push!(ps,GP.Ps(rs[i],deb,gp75))
       push!(cs,sqrt(gp75.γ*GP.Ps(rs[i],deb,gp75)/rs[i]))
       push!(rh,ρfin+0.005*i)
       push!(rs,ρdeb-0.02*i)
       local Phz,Ehz,uz,Dz=GP.Hugoniot(rh[i],fin,gp75)
       push!(uh,uz)
       push!(us,us[i]-2/(gp75.γ-1)*(cs[i+1]-cs[i]))	
       push!(vh,1/(ρfin+0.005*i))
       push!(vs,1/(ρdeb-0.02*i))
       push!(eh,Ehz)
       push!(es,GP.Ps(rs[i],deb,gp75)/(gp75.γ-1)/rs[i])
end
Pchoc,Echoc,uchoc,Dchoc = GP.Hugoniot(0.265574,fin,gp75)
etatChoc=GP.Etat("Etat Choc",0.265574,Echoc,gp75)

f = open("./Pu-ref.dat", "w")
for i=1:length(uh)
	print(f, uh[i], " ", ph[i], "\n")
end
print(f,"\n")
for i=1:length(us)
	print(f, us[i], " ", ps[i], "\n")
end
close(f)

f = open("VE-ref.dat", "w")
for i=1:length(vh)
	print(f, vh[i], " ", eh[i], "\n")
end
print(f,"\n")
for i=1:length(us)
	print(f, vs[i], " ", es[i], "\n")
end
close(f)

plot(rh,ph)
plot!(rs,ps)
plot(uh,ph,title="P(u)",xlabel=" u",ylabel="P",label = "H")
plot!(us,ps,label = "S")
savefig("Pu-ref.pdf")
n=length(ph)
dpduH=(ph[n]-ph[n-1])/(uh[n]-uh[n-1])
dpduS=(ps[n]-ps[n-1])/(us[n]-us[n-1])
ust = ( -ph[n-1] + ps[n-1] + dpduH * uh[n-1] - dpduS * us[n-1] ) / ( dpduH - dpduS )
pst= (dpduH * ps[n-1] - dpduS * (ph[n-1] + dpduH * (-uh[n-1] + us[n-1])))/( dpduH - dpduS)
println(" p* = ",pst,"	u*= ",ust)

ρchoc=ρfin*pst/(pst-ρfin*ust^2)
ρdet=ρdeb*(pst/pdeb)^(1/gp75.γ)
println("  Solution exacte : ")
println(" p = ",pdeb,"			",pst,"	",pst,"	",pfin)
println(" ρ = ",ρdeb,"			",ρdet,"	",ρchoc,"	",ρfin)
println(" u = ",udeb,"			",ust,"	",ust,"	",ufin)
println(" ondes = HP ",-cs[1]," debDét ",ust-cs[1]," finDét	",ust,"	choc ",pst/ρfin/ust," BP")

plot(vh,eh)
plot!(vs,es)
plot(vh,eh,title="(V,E)",xlabel="V",ylabel="E",label = "H")
plot!(vs,es,label = "S")
savefig("VE-ref.pdf")


