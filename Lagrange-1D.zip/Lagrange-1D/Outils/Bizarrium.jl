#  OH  - 1/06/2023 
#  Bizarrium.jl
using DataFrames,Plots

include("./MateriauJ.jl")

bz = Materiau.Bizarrium("Bz")
Materiau.LireDonnees(bz,"Bz.mat")

# Hugoniot du Bizarrium  ( O = Origine, S = choc, I= Inflexion, M = chgt de pole  )
etats4 = ["O","S","I","M"]
ρ=[1, 1.207221, 1.333115, 1.4343 ]*Materiau.getVal(bz,"ρo")
E = [0, 215555., 447801., 670754.]
N=4
p = zeros(Float64, N);
c = zeros(Float64, N);
T = zeros(Float64, N);
S = zeros(Float64, N);
g = zeros(Float64, N);
Materiau.calculEtats(bz,0,N-1,p,c,T,g,S,ρ,E)
etatsBz4= DataFrame(nom=etats4,ρ=ρ,E=E,P=p,T=T,c=c,S=S,df=g)
println(etatsBz4)

# Cas test  : Pb de Riemann du Bizarrium
etats8 = ["G", "Y1", "Y2", "YZ", "ZY", "Z2", "Z1", "D"]
ρ=[1.428571, 1.376273, 1.046421, 1.0100384, 1.414975, 1.257522, 1.207221, 1.]*Materiau.getVal(bz,"ρo")
E=[ 4.48658*10^6, 4.23605*10^6, 2.68203*10^6, 2.53678*10^6, 609505.,  306228., 215555., 0. ]
N=8
p = zeros(Float64, N);
c = zeros(Float64, N);
T = zeros(Float64, N);
S = zeros(Float64, N);
g = zeros(Float64, N);
Materiau.calculEtats(bz,0,N-1,p,c,T,g,S,ρ,E)
etatsBz8= DataFrame(nom=etats8,ρ=ρ,E=E,P=p,T=T,c=c,S=S,df=g)
figρE = scatter(ρ,E,title="Bizarrium",label="")
