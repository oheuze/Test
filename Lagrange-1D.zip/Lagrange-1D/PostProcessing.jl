#  OH  14/09/2023
println("- PostProcessing du cas de calcul : "*nom)
using CSV,DataFrames,Plots

df = DataFrame(CSV.File(dirCas*"/"*nom*".dat";header=1, delim=" "))
rename!(df,[:x,:ρ,:u,:p,:e,:t,:c,:g])
figρx = plot(df.x,df.ρ,xlabel="x",ylabel="ρ (kg/m3)",title=nom,label="ρ(x)")
figρx = scatter!(df.x,df.ρ,xlabel="x",ylabel="ρ (kg/m3)",title=nom,label="ρ(x)")
savefig(nom*"-ρx.png")
savefig(nom*"-ρx.pdf")
figex = scatter(df.x,df.e,xlabel="x",ylabel="e (kJ/kg)",title=nom,label="e(x)")
savefig(nom*"-ex.png")
figux = scatter(df.x,df.u,xlabel="x",ylabel="u (m/s)",title=nom,label="u(x)")
savefig(nom*"-ux.png")
figρe = plot(df.ρ,df.e,xlabel="ρ (kg/m3)",ylabel="e (J/kg)",title=nom,label="e(ρ)")
pdf=(figρe,nom*"-ρe.pdf")	#  aucun résultat  !
savefig(nom*"-ρe.png")
figPu = plot(df.u,df.p/1e9,xlabel="u (m/s)",ylabel="p (GPa)",title=nom,label="P(u)")
savefig(nom*"-Pu.png")
println(" Figures calculées :	figρx,	figex,  figux , figρe,	figPu ")
figρx = plot(df.x,df.ρ,xlabel="x",ylabel="ρ (kg/m3)",title=nom,label="ρ(x)")
figρx = scatter!(df.x,df.ρ,xlabel="x",ylabel="ρ (kg/m3)",title=nom,label="ρ(x)")
