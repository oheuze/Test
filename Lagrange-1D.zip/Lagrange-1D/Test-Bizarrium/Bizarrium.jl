nom="Bizarrium"
test=nom
include("../Lag-1D.jl")

