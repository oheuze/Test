#
#  H. Jourdren
#
#  CEA/DAM 30/01/2022 
#
#  Mon *premier* CODE HYDRODYNAMIQUE en langage Julia...
#
# Modifié O. Heuzé  5/05/2023	:	EE en C++
#
# αβγδεζηθικλμνξοπρςστυχψφωϕΓΔΘΛΞΠΣΦΨΩ

dirCas=pwd()
dirCode=dirCas*"/.."
dirMat=dirCode*"/Matériaux"
nghost = 2; 
ideb=nghost+1;
bcMur="Mur";bcLibre="Libre";
nomdeb="Gauche"
nomfin="Droit"
dta = 0
params=0
i=0
global ficPre=""
global ficPost=""
if (!@isdefined test) test=uppercase(nom) end
println("test = ",test)
println("nom = ",nom)

include("LagLib.jl")
include("foncsXML.jl")
include("RiemannSolvers.jl")
include("MateriauJ.jl")
include("Thermo.jl")
Initialisation()

if silent == -1
#	for i in ideb:ifin
#		println("Init, ", 0.5*(x[i]+x[i+1]), ", ", ρmat[i], ", ", 		
#		umat[i], ", ", pmat[i], ", ", emat[i], ", ", 
#		cmat[i], ", ", gmat[i], "\n")
#	end
end

