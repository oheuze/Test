hyb=milEoS[1]
Materiau.ecrire(hyb)
N=3
p = zeros(Float64, N)
T = zeros(Float64, N)
c = zeros(Float64, N)
S = zeros(Float64, N)
g = zeros(Float64, N)
ρ = [ 7984.354545292348   7984.354545292348   7984.354545292348 ]
ε = [ 61522.012913   61522.012913   61522.012913   ]
ρ = ones(Float64, N) .* 7984.354545292348
ε = ones(Float64, N) .* 61522.012913
Materiau.calculEtats(hyb,1,N,p,c,T,S,g,ρ,ε)
p
c
T
