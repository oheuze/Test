function convertTCtoString(TC)
	tc=""
	for j=1:Hybride.nE
		for i=1:Hybride.nV
                	#println(i," , ",j," : ",Hybride.typeCase[i,j])
                 	if TC[i,Hybride.nE+1-j]=="Vide"        ycase="." end
                 	if TC[i,Hybride.nE+1-j]=="Mono"        ycase="o" end
                 	if TC[i,Hybride.nE+1-j]=="Mixte"        ycase="+" end           
                 	if TC[i,Hybride.nE+1-j]=="Multi"        ycase="x" end
                 	tc=tc*ycase
                 end
                 tc=tc*"\n"
	end
	return tc
end

function convertStringToTC(chaine)
	TC=Matrix{String}(undef,Hybride.nV,Hybride.nE)
	for j=1:Hybride.nE
		strj=SubString(chaine,1+(j-1)*(Hybride.nV+1),j*(Hybride.nV+1))
		for i=1:Hybride.nV
                	strij=SubString(strj,i,i)
                	#println(i," , ",j," : ",Hybride.typeCase[i,j])
                 	if strij=="." TC[i,Hybride.nE+1-j]="Vide" end
                 	if strij=="o" TC[i,Hybride.nE+1-j]="Mono" end
                 	if strij=="+" TC[i,Hybride.nE+1-j]="Mixte" end           
                 	if strij=="x" TC[i,Hybride.nE+1-j]="Multi" end
                 end
	end
	return TC
end

tcs=convertTCtoString(Hybride.typeCase);
println(tcs)
tCase=convertStringToTC(tcs);
tCase==Hybride.typeCase





