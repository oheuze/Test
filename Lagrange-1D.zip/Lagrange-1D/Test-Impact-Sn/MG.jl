nom="MG"
test=nom
include("../Lag-1D.jl")

