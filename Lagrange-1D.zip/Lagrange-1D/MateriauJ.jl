module Materiau

export LireDonnees, InitParam, detailler, setParam, getVal, ecrire, calculPc, calculEtats, calculEtatsRhoT, calculEtatVE
export Mat, MatGP, MatBz, MatMGC, MatHybride

using CxxWrap
@wrapmodule( () -> joinpath(@__DIR__, "cmake-build-debug", "libMat_wrap"), :define_Mat_module)

function __init__()
    @initcxx
end

end
