nom="Sod"
test=nom
include("../Lag-1D.jl")

