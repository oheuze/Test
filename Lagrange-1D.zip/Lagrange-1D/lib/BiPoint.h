#ifndef _BIPOINT_H 
#define _BIPOINT_H 

#include <string> 
#include <vector> 
#include <iostream> 
#include "PointXY.h"

using namespace std;

class BiPoint 
{ 
	public: 
	
	PointXY pt1,pt2; 

	BiPoint(); 
	BiPoint(std::string chaine);
	BiPoint(PointXY Point1,PointXY Point2); 
	
	~BiPoint(); 

	void ecrire(); 
	
} ; 
 
#endif 
