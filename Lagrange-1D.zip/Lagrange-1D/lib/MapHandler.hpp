#ifndef _MapHandler_ 
#define _MapHandler_ 

#include <iostream> 
#include <fstream>
#include <map>
#include "SAXHandler.hpp"
#include "ParserSAX.hpp"
using namespace std;

class MapHandler : public SAXHandler {

protected:

public:
	std::string mat,nom,element,chaine;
	map <string,string> parametres;

	void StartDocument();
	void StartElement(string Element,map <string,string>  Attributs);
	void EndElement(string Element);
	void Characters(string CaracStr);
	void EndDocument();

	string 	recupString(std::string motClef,map <string,string> Attr);
	int  	recupInt   (std::string motClef,map <string,string> Attr);
	double 	recupDouble(std::string motClef,map <string,string> Attr);
	string trim(string str);
};

#endif
