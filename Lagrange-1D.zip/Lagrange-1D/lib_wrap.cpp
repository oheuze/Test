#include "lib/Mat.h"
#include "jlcxx/jlcxx.hpp"

namespace jlcxx
{
    template<> struct SuperType<MatGP>		{ using type = Mat; };
    template<> struct SuperType<MatBz>		{ using type = Mat; };
    template<> struct SuperType<MatMGC>		{ using type = Mat; };
    template<> struct SuperType<MatHybride>	{ using type = Mat; };
}

JLCXX_MODULE define_Mat_module(jlcxx::Module& mod)
{
    mod.add_type<Mat>("Mat")
        .constructor<const std::string&>()
        .method("LireDonnees", 	&Mat::LireDonnees)
        .method("InitParam",    &Mat::InitParam)
        .method("detailler",   	&Mat::detailler)
        .method("setParam",    	&Mat::setParam)
        .method("getVal",    	&Mat::getVal)
        .method("ecrire",    	&Mat::ecrire)
        .method("calculPc",    	&Mat::calculPc)
        .method("calculEtats", 	&Mat::calculEtats)
        .method("calculEtatsRhoT", &Mat::calculEtatsRhoT)
        .method("calculEtatVE",	&Mat::calculEtatVE);
        
    mod.add_type<MatGP>("GP", jlcxx::julia_base_type<Mat>())
        .constructor<const std::string&>();
                
    mod.add_type<MatBz>("Bizarrium", jlcxx::julia_base_type<Mat>())
        .constructor<const std::string&>();
                
    mod.add_type<MatMGC>("MGC", jlcxx::julia_base_type<Mat>())
        .constructor<const std::string&>();
                
    mod.add_type<MatHybride>("Hybride", jlcxx::julia_base_type<Mat>())
        .constructor<const std::string&>();
    
}
